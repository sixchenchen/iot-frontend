import { test, expect, type Page } from '@playwright/test'

/**
 * ============================================================================
 * 端到端用例（真实认证/路由行为，接口全部使用 Playwright 路由拦截 Mock）
 * ============================================================================
 * 设计原则：
 *   - 不依赖真实后端，保证本地与 CI 都能稳定运行；
 *   - 每个用例执行前清空 localStorage，避免登录态串扰；
 *   - 只断言用户可观察的行为（URL、页面元素、提示文案）。
 * ============================================================================
 */

const LOGIN_API = '**/api/auth/login'

/** 清空本地存储，保证用例从「未登录」开始。 */
async function resetStorage(page: Page): Promise<void> {
  await page.addInitScript(() => window.localStorage.clear())
  await page.route('**/api/auth/logout', (route) => route.fulfill({ json: { code: 0, data: null } }))
}

test('未登录访问受保护页面会跳转登录页并带上回跳地址', async ({ page }) => {
  await resetStorage(page)
  await page.goto('/device/mine')

  await expect(page).toHaveURL(/\/login/)
  await expect(page).toHaveURL(/redirect=/)
  await expect(page.getByRole('heading', { name: 'IoT 设备管理平台' })).toBeVisible()
  await expect(page.getByPlaceholder('请输入用户名')).toBeVisible()
})

test('登录成功后按角色进入设备管理页并展示用户信息', async ({ page }) => {
  await resetStorage(page)

  await page.route(LOGIN_API, async (route) => {
    await route.fulfill({
      json: {
        code: 200,
        message: 'ok',
        data: {
          token: 'mock-access-token',
          refreshToken: 'mock-refresh-token',
          username: 'admin',
          nickname: '管理员',
          roles: ['ADMIN'],
          permissions: ['device:list'],
          expiresAt: new Date(Date.now() + 3600_000).toISOString(),
          lastLoginTime: null,
        },
      },
    })
  })
  // 登录后的设备列表请求同样 Mock，避免测试依赖真实后端。
  await page.route('**/api/admin/devices*', (route) =>
    route.fulfill({ json: { code: 200, data: { records: [], total: 0, size: 10, current: 1 } } }),
  )

  await page.goto('/login')
  await page.getByPlaceholder('请输入用户名').fill('admin')
  await page.getByPlaceholder('请输入密码').fill('admin12345')
  await page.getByRole('button', { name: /登\s*录/ }).click()

  await expect(page).toHaveURL(/\/device\/manage/)
  await expect(page.getByText('欢迎您，管理员')).toBeVisible()
  await expect(page.getByRole('heading', { name: '设备管理' })).toBeVisible()
})

test('登录失败时展示后端返回的错误原因，且不跳转页面', async ({ page }) => {
  await resetStorage(page)

  await page.route(LOGIN_API, (route) =>
    route.fulfill({
      status: 401,
      json: { code: 401, message: '用户名或密码错误', data: null },
    }),
  )

  await page.goto('/login')
  await page.getByPlaceholder('请输入用户名').fill('admin')
  await page.getByPlaceholder('请输入密码').fill('wrong-password')
  await page.getByRole('button', { name: /登\s*录/ }).click()

  await expect(page.locator('.el-message').filter({ hasText: '用户名或密码错误' })).toBeVisible()
  await expect(page).toHaveURL(/\/login/)
})

test('注册表单要求二次确认密码与协议勾选', async ({ page }) => {
  await resetStorage(page)
  await page.goto('/login')

  await page.getByRole('tab', { name: '注册' }).click()
  await page.getByPlaceholder('用户名（4-32 位字母、数字、下划线）').fill('newuser')
  await page.getByPlaceholder('密码（8-64 位，需包含字母和数字）').fill('abc12345')
  await page.getByPlaceholder('请再次输入密码').fill('abc1234')
  await page.getByRole('button', { name: /注\s*册/ }).click()

  await expect(page.getByText('两次输入的密码不一致')).toBeVisible()
})
