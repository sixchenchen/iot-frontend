import { request } from '@/lib/request'
import type { Device } from '@/types/device'
import type { PageQuery, PageResult } from '@/types/api'

/**
 * ============================================================================
 * 设备接口定义（features/device/api）
 * ============================================================================
 * 分两组：
 *   - 管理端 /admin/devices：分页查询、新增、删除（需要 ADMIN/OPS 角色）；
 *   - 用户端 /user/devices：我的设备、绑定、解绑、控制（需要登录用户）。
 *
 * ⚠️ 已知问题（详见《整改清单与详细修改建议.md》）：
 *   - P1-14 此处的 PageResult 与 src/types/api.ts 的 PaginatedResponse 是两套分页
 *           模型；后端真实返回是 MyBatis-Plus 的 { records, total, size, current }，
 *           应将本定义上移到 types/api.ts 统一维护。
 *   - 接口路径、分页字段名（pageNum/pageSize）需与后端文档保持一致，
 *     建议由 OpenAPI 生成或补充接口契约测试。
 *   - 控制/绑定等写操作缺少幂等键与防重复提交策略（可配合按钮 loading + 后端幂等）。
 * ============================================================================
 */

export interface DeviceQuery extends PageQuery {
  keyword?: string
}

export interface BindRequest {
  deviceId?: string
  bindCode?: string
}

export interface ControlRequest {
  deviceId: string
  action: string
  target: string
  channel?: number
  params: Record<string, unknown>
}

export const deviceApi = {
  // ================= 管理端接口 =================
  
  // 分页查询设备
  listManage: (params: DeviceQuery) =>
    request<PageResult<Device>>({
      url: '/admin/devices',
      method: 'get',
      params,
    }),

  // 新增设备 (注意：后端要求 deviceId 必填)
  addDevice: (data: { deviceId: string; deviceName?: string; product?: string; location?: string }) =>
    request<void>({
      url: '/admin/devices',
      method: 'post',
      data,
    }),

  // 删除设备
  deleteDevice: (id: number) =>
    request<void>({
      url: `/admin/devices/${id}`,
      method: 'delete',
    }),

  // ================= 用户端接口 =================

  // 获取我的设备 (文档里没有 keyword 参数，只有分页)
  listMine: (params: DeviceQuery) =>
    request<PageResult<Device>>({
      url: '/user/devices/my',
      method: 'get',
      params: {
        pageNum: params.pageNum,
        pageSize: params.pageSize,
      },
    }),

  // 绑定设备
  bindDevice: (data: BindRequest) =>
    request<void>({
      url: '/user/devices/bind',
      method: 'post',
      data,
    }),

  // 解绑设备
  unbindDevice: (data: BindRequest) =>
    request<void>({
      url: '/user/devices/unbind',
      method: 'post',
      data,
    }),

  // 控制设备
  controlDevice: (data: ControlRequest) =>
    request<void>({
      url: '/user/devices/control',
      method: 'post',
      data,
    }),
}