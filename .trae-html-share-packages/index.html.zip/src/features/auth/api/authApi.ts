import { request } from '@/lib/request'

/**
 * ============================================================================
 * 认证接口定义（features/auth/api）
 * ============================================================================
 * 当前提供：登录 / 注册 / 刷新 / 登出。
 *
 * ⚠️ 契约与缺口（详见《整改清单与详细修改建议.md》）：
 *   - 响应字段 token / refreshToken / expiresAt 的命名与后端强绑定，建议由
 *     OpenAPI 生成类型，避免手写 DTO 漂移（P1-14）。
 *   - 登录响应包含 lastLoginTime / roles / permissions，但 store 只消费了部分
 *     字段（P1-8）。
 *   - 缺少企业级认证常见接口：/auth/me（权限校准）、/auth/forgot-password、
 *     /auth/reset-password、/auth/change-password、/auth/captcha、/auth/sessions
 *     （见 P2-1、P2-2、P2-6、P2-10、P1-6）。
 *   - 所有函数都经过统一 request 层，因此返回值已是后端 body.data（不是 AxiosResponse）。
 * ============================================================================
 */

// 所有对外导出的类型与接口都使用 export，方便其它模块按需引入。
export interface LoginPayload {
  username: string
  password: string
}

export interface RegisterPayload {
  username: string
  password: string
  nickname?: string
  email?: string
  phone?: string
}

export interface LoginResponse {
  token: string
  username: string
  nickname: string
  refreshToken: string
  lastLoginTime: string | null
  roles: string[]
  permissions: string[]
  expiresAt: string
}

export const authApi = {
  // 账号密码登录：成功返回 token / refreshToken / 角色 / 权限 / 过期时间。
  // ⚠️ 若返回 HTTP 401，request.ts 当前会误走刷新流程（P1-1），需配合白名单修复。
  login: (payload: LoginPayload) =>
    request<LoginResponse>({
      url: '/auth/login',
      method: 'post',
      data: payload,
    }),

  // 自助注册。⚠️ P1-17：当前无邀请码/验证码/协议勾选；B 端通常应关闭自助注册，
  // 改为管理员开通或邀请制，并在这里增加对应字段（inviteCode / captchaToken）。
  register: (payload: RegisterPayload) =>
    request<{ userId: number; username: string; nickname: string }>({
      url: '/auth/register',
      method: 'post',
      data: payload,
    }),

  // 刷新 token。注意：request.ts 中的 401 自动刷新是「裸 axios」实现（P1-3），
  // 本方法目前只在手动刷新场景使用，二者应统一。
  refresh: (refreshToken: string) =>
    request<LoginResponse>({
      url: '/auth/refresh',
      method: 'post',
      data: { refreshToken },
    }),

  // 登出接口：请求体带 refreshToken，便于后端吊销指定会话。
  // TODO(P2-11): 增加 logoutAll(refreshToken) 用于「退出全部设备」。
  logout: (refreshToken?: string) =>
    request<void>({
      url: '/auth/logout',
      method: 'post',
      data: { refreshToken },
    }),
}
