import { isAxiosError } from 'axios'

export interface ErrorPayload {
  code?: number
  message?: string
}

/**
 * 从 unknown 错误中安全提取可读消息。
 * 优先级：Axios 响应体 message > Error.message > 字符串 > fallback
 *
 * ⚠️ 必须先判断 AxiosError：它继承自 Error，若先走 `instanceof Error` 分支，
 * 只会拿到 "Request failed with status code 401"，从而丢失后端真实文案。
 */
export function getErrorMessage(
  error: unknown,
  fallback = '请求失败，请稍后重试',
): string {
  if (isAxiosError(error)) {
    const data = error.response?.data as ErrorPayload | undefined
    if (typeof data?.message === 'string' && data.message) {
      return data.message
    }
    if (error.message) return error.message
    return fallback
  }

  if (error instanceof Error) {
    return error.message || fallback
  }

  if (typeof error === 'string') {
    return error || fallback
  }

  if (typeof error === 'object' && error !== null && 'message' in error) {
    const msg = (error as { message?: unknown }).message
    if (typeof msg === 'string' && msg) return msg
  }

  return fallback
}
