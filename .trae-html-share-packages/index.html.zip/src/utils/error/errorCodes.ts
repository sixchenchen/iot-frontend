export const BUSINESS_ERROR_MESSAGES: Record<number, string> = {
  1001: '设备已被占用',
  1002: '设备不存在',
}

export function getBusinessMessage(code?: number): string | undefined {
  return code != null ? BUSINESS_ERROR_MESSAGES[code] : undefined
}
