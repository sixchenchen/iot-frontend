import type { RouteRecordRaw } from 'vue-router'
import { Monitor, Setting } from '@element-plus/icons-vue'

/**
 * ============================================================================
 * 路由表（静态路由）
 * ============================================================================
 * meta 约定见 src/types/router.d.ts。
 *
 * 菜单不再在 MainLayout 中硬编码，而是由 src/router/menu.ts 根据本文件的
 * meta（title / icon / roles / permission）动态生成，做到「路由即菜单」。
 * ============================================================================
 */
export const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/pages/login/LoginPage.vue'),
    meta: { public: true, title: '登录' },
  },
  {
    // 布局路由：访问根路径时默认进入「我的设备」，避免出现空白内容区。
    path: '/',
    redirect: '/device/mine',
    component: () => import('@/components/layout/MainLayout.vue'),
    children: [
      {
        path: 'device/mine',
        name: 'MyDevices',
        component: () => import('@/pages/device/DeviceListPage.vue'),
        meta: { title: '我的设备', icon: Monitor, permission: 'device:list' },
      },
      {
        path: 'device/manage',
        name: 'DeviceManage',
        component: () => import('@/pages/device/DeviceListPage.vue'),
        meta: {
          title: '设备管理',
          icon: Setting,
          roles: ['ADMIN', 'OPS'],
          // 管理端在角色之外再要求设备读取权限；写操作由后端二次鉴权。
          permission: 'device:list',
        },
      },
    ],
  },
  {
    path: '/403',
    name: 'Forbidden',
    component: () => import('@/pages/error/ForbiddenPage.vue'),
    meta: { public: true, title: '无访问权限' },
  },
  {
    path: '/500',
    name: 'ServerError',
    component: () => import('@/pages/error/ServerErrorPage.vue'),
    meta: { public: true, title: '服务异常' },
  },
  {
    // 兜底路由：保留原始 URL 语义，展示 404 页面而不是静默跳回首页，
    // 既方便用户感知「地址写错」，也方便线上排障定位错误链接。
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/pages/error/NotFoundPage.vue'),
    meta: { public: true, title: '页面不存在' },
  },
]
