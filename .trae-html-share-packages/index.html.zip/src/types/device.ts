/**
 * 设备领域模型。
 *
 * 字段说明：
 *   - online：0=离线、1=在线（用 number 而非 boolean，是为了与后端/数据库保持一致）；
 *   - lastHeartbeatTime：最后心跳时间，IoT 场景下应配合 WebSocket 实时刷新；
 *   - capabilities / currentState：设备能力与当前状态（JSON），前端做控制面板时使用；
 *   - pubkey / bindCode / otaState 等仅管理端返回。
 *
 * 注意：设备在线状态目前只在进入页面时拉取一次，没有实时订阅（见分析文档 5.5
 * 「WebSocket 实时层缺失」）。后续建议新增 useDeviceRealtime 组合式函数统一更新。
 */
export interface Device {
  id: number
  deviceId: string
  deviceName: string | null
  product: string | null
  firmware: string | null
  location: string | null
  online: number // 0-离线, 1-在线
  lastHeartbeatTime: string | null
  uptime: number | null
  capabilities?: Record<string, unknown> | null
  currentState?: Record<string, unknown> | null
  
  // 只有管理端才有的字段
  pubkey?: string | null
  bindCode?: string | null
  groupId?: number | null
  otaState?: string | null
  otaProgress?: number | null
  lastPayload?: string | null
  createTime?: string
  updateTime?: string
}