<template>
  <!--
    主布局：左侧菜单 + 顶部 Header + 右侧内容区。
    菜单由路由表动态生成（src/router/menu.ts），新增页面只需在 routes.ts 中
    配置 meta.title / icon / roles / permission，无需再改本组件。
  -->
  <el-container class="layout-container">
    <!-- 左侧菜单 -->
    <el-aside width="200px" class="aside">
      <div class="logo">IoT 平台</div>
      <el-menu
        :default-active="route.path"
        class="el-menu-vertical"
        router
        background-color="#304156"
        text-color="#bfcbd9"
        active-text-color="#409EFF"
      >
        <el-menu-item v-for="item in menus" :key="item.path" :index="item.path">
          <el-icon v-if="item.icon"><component :is="item.icon" /></el-icon>
          <span>{{ item.title }}</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <!-- 顶部 Header -->
      <el-header class="header">
        <div class="user-info">
          <span>欢迎您，{{ authStore.user?.nickname || authStore.user?.username }}</span>
          <el-button type="danger" link @click="handleLogout">退出登录</el-button>
        </div>
      </el-header>

      <!-- 右侧内容区 -->
      <el-main class="main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useAuthStore } from '@/stores/useAuthStore'
import { routes } from '@/router/routes'
import { buildMenus } from '@/router/menu'

/**
 * 布局组件：
 *  - 菜单：buildMenus 根据路由 meta 与当前用户权限过滤，避免硬编码与权限漏判；
 *  - default-active 绑定当前 path，保证刷新后高亮正确；
 *  - 退出登录二次确认，避免误触导致未保存内容丢失。
 */
const route = useRoute()
const router = useRouter()
const authStore = useAuthStore()

const menus = computed(() => buildMenus(routes, authStore))

const handleLogout = async () => {
  try {
    await ElMessageBox.confirm('确定要退出登录吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
      center: true,
    })
  } catch {
    return // 用户取消
  }

  await authStore.logout()
  ElMessage.success('已安全退出')
  await router.push('/login')
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}
.aside {
  background-color: #304156;
  color: white;
}
.logo {
  height: 60px;
  line-height: 60px;
  text-align: center;
  font-size: 20px;
  font-weight: bold;
  color: #fff;
  background-color: #2b3643;
}
.el-menu-vertical {
  border-right: none;
}
.header {
  background-color: #fff;
  border-bottom: 1px solid #e6e6e6;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.user-info {
  display: flex;
  align-items: center;
  gap: 15px;
}
.main {
  background-color: #f0f2f5;
  padding: 20px;
}
</style>
